//
// Eurotop_r2p_q_Final_data.cpp
//
// Code generation for function 'Eurotop_r2p_q_Final_data'
//

// Include files
#include "Eurotop_r2p_q_Final_data.h"
#include "rt_nonfinite.h"

// Variable Definitions
unsigned int state[625];

boolean_T isInitialized_Eurotop_r2p_q_Final{false};

// End of code generation (Eurotop_r2p_q_Final_data.cpp)
