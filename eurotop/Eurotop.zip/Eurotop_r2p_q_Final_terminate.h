//
// Eurotop_r2p_q_Final_terminate.h
//
// Code generation for function 'Eurotop_r2p_q_Final_terminate'
//

#ifndef EUROTOP_R2P_Q_FINAL_TERMINATE_H
#define EUROTOP_R2P_Q_FINAL_TERMINATE_H

// Include files
#include "Eurotop_r2p_q_Final_spec.h"
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
EUROTOP_R2P_Q_FINAL_DLL_EXPORT extern void Eurotop_r2p_q_Final_terminate();

#endif
// End of code generation (Eurotop_r2p_q_Final_terminate.h)
