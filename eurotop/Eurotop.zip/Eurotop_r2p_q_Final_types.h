//
// Eurotop_r2p_q_Final_types.h
//
// Code generation for function 'Eurotop_r2p_q_Final'
//

#ifndef EUROTOP_R2P_Q_FINAL_TYPES_H
#define EUROTOP_R2P_Q_FINAL_TYPES_H

// Include files
#include "rtwtypes.h"

#endif
// End of code generation (Eurotop_r2p_q_Final_types.h)
