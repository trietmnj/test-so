//
// Eurotop_r2p_q_Final_data.h
//
// Code generation for function 'Eurotop_r2p_q_Final_data'
//

#ifndef EUROTOP_R2P_Q_FINAL_DATA_H
#define EUROTOP_R2P_Q_FINAL_DATA_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Variable Declarations
extern unsigned int state[625];
extern boolean_T isInitialized_Eurotop_r2p_q_Final;

#endif
// End of code generation (Eurotop_r2p_q_Final_data.h)
