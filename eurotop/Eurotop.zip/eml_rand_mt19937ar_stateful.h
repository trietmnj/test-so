//
// eml_rand_mt19937ar_stateful.h
//
// Code generation for function 'eml_rand_mt19937ar_stateful'
//

#ifndef EML_RAND_MT19937AR_STATEFUL_H
#define EML_RAND_MT19937AR_STATEFUL_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
void eml_rand_mt19937ar_stateful_init();

#endif
// End of code generation (eml_rand_mt19937ar_stateful.h)
