//
// Eurotop_r2p_q_Final_rtwutil.h
//
// Code generation for function 'Eurotop_r2p_q_Final_rtwutil'
//

#ifndef EUROTOP_R2P_Q_FINAL_RTWUTIL_H
#define EUROTOP_R2P_Q_FINAL_RTWUTIL_H

// Include files
#include "Eurotop_r2p_q_Final_spec.h"
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
EUROTOP_R2P_Q_FINAL_DLL_EXPORT extern double rt_powd_snf(double u0, double u1);

#endif
// End of code generation (Eurotop_r2p_q_Final_rtwutil.h)
