//
// Eurotop_r2p_q_Final_spec.h
//
// Code generation for function 'Eurotop_r2p_q_Final'
//

#ifndef EUROTOP_R2P_Q_FINAL_SPEC_H
#define EUROTOP_R2P_Q_FINAL_SPEC_H

// Include files
#ifdef EUROTOP_R2P_Q_FINAL_XIL_BUILD
#if defined(_MSC_VER) || defined(__LCC__)
#define EUROTOP_R2P_Q_FINAL_DLL_EXPORT __declspec(dllimport)
#else
#define EUROTOP_R2P_Q_FINAL_DLL_EXPORT __attribute__((visibility("default")))
#endif
#elif defined(BUILDING_EUROTOP_R2P_Q_FINAL)
#if defined(_MSC_VER) || defined(__LCC__)
#define EUROTOP_R2P_Q_FINAL_DLL_EXPORT __declspec(dllexport)
#else
#define EUROTOP_R2P_Q_FINAL_DLL_EXPORT __attribute__((visibility("default")))
#endif
#else
#define EUROTOP_R2P_Q_FINAL_DLL_EXPORT
#endif

#endif
// End of code generation (Eurotop_r2p_q_Final_spec.h)
