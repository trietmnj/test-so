//
// randn.h
//
// Code generation for function 'randn'
//

#ifndef RANDN_H
#define RANDN_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
double randn();

}

#endif
// End of code generation (randn.h)
