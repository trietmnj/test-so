//
// Eurotop_r2p_q_Final_initialize.cpp
//
// Code generation for function 'Eurotop_r2p_q_Final_initialize'
//

// Include files
#include "Eurotop_r2p_q_Final_initialize.h"
#include "Eurotop_r2p_q_Final_data.h"
#include "eml_rand_mt19937ar_stateful.h"
#include "rt_nonfinite.h"

// Function Definitions
void Eurotop_r2p_q_Final_initialize()
{
  eml_rand_mt19937ar_stateful_init();
  isInitialized_Eurotop_r2p_q_Final = true;
}

// End of code generation (Eurotop_r2p_q_Final_initialize.cpp)
