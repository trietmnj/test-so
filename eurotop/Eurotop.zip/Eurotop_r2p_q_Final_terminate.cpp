//
// Eurotop_r2p_q_Final_terminate.cpp
//
// Code generation for function 'Eurotop_r2p_q_Final_terminate'
//

// Include files
#include "Eurotop_r2p_q_Final_terminate.h"
#include "Eurotop_r2p_q_Final_data.h"
#include "rt_nonfinite.h"

// Function Definitions
void Eurotop_r2p_q_Final_terminate()
{
  isInitialized_Eurotop_r2p_q_Final = false;
}

// End of code generation (Eurotop_r2p_q_Final_terminate.cpp)
